/**
 * Created by Administrator on 2018/11/13.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','swiper','validata','style'],function ($,wui,Swiper,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        var api = validata.isApi();
        console.log(api);
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        //轮播图
        $(".swiper-container").swiper({
            loop: true,
            autoplay: 4000
        });
        $('.swiper-slide img').height($('.swiper-slide img').width()*0.43);
        $.ajax({
            //通过ajax传页数参数获取当前页数的数据
            url:api+'?page='+1,
            type:'POST',
            cache:false,
            data:{
                module:'market',
                method:'market',
                request_mode:'get',
                key:key,
                sign:sign,
                timestamp:timestamp
            },
            dataType:"json",
            success:function(data){
                console.log(data);
                // $('.weui-loadmore').attr('num',data.pageTotal);
                //把通过php处理的html和数据，写入容器底部
                var indexlist = '';
                for(var i=0;i<data.result.length;i++){
                    var index = data.result[i];
                    indexlist +='<li><a href="#"><div class="courses_img"><img src="images/img_03.png"></div><div class="courses_brief"><h5>痛风谈吃：细说痛风患者如何饮食</h5><div class="courses_brief_bottom"><span>销量:<b>6655</b></span><img src="images/line.png"/><span>点击量:<b>25525</b></span></div></div></a></li>';
                }
                $('.courses_list_info').append(indexlist);
                $('.courses_list_info li .courses_img img').height($('.courses_list_info li .courses_img').width()*1.33);
            },
            error:function(XMLHttpRequest, textStatus, errorThrown){
                console.log('错误，请刷新页面')
                console.log(XMLHttpRequest)
                console.log(textStatus)
                console.log(errorThrown)
            }
        });
        // //记录状态
        var state=true;
        $('.weui-loadmore').on('click',function () {
            //获取当前页数，默认第一页
            var now = $('.weui-loadmore').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.weui-loadmore').attr('num');
            if(state==true){
                state=false;
                $('.weui-loadmore .weui-loading').show();
                $('.weui-loadmore .weui-loadmore__tips').text('正在加载');
                setTimeout(function(){
                    //当前页数++
                    now++;
                    //记录当前为第二页
                    $('.weui-loadmore').attr('now',now);
                    $.ajax({
                        //通过ajax传页数参数获取当前页数的数据
                        url:api+'?page='+now,
                        type:'POST',
                        cache:false,
                        data:{
                            module:'market',
                            method:'market',
                            request_mode:'get',
                            key:key,
                            sign:sign,
                            timestamp:timestamp
                        },
                        dataType:"json",
                        success:function(data){
                            console.log(data);
                            //把通过php处理的html和数据，写入容器底部
                            var indexlist = '';
                            for(var i=0;i<data.result.length;i++){
                                var index = data.result[i];
                                indexlist +='<li><a href="#"><div class="courses_img"><img src="images/img_03.png"></div><div class="courses_brief"><h5>痛风谈吃：细说痛风患者如何饮食</h5><div class="courses_brief_bottom"><span>销量:<b>6655</b></span><img src="images/line.png"/><span>点击量:<b>25525</b></span></div></div><div class="courses_right fr"><button><b>￥</b><span>19.99</span></button><div><span>会员免费</span></div></div></a></li>';
                            }
                            $('.courses_list_info').append(indexlist);
                            $('.weui-loadmore .weui-loading').hide();
                            //如果当前页大于等于总页数就提示没有更多数据
                            if(now>=num){
                                $('.weui-loadmore .weui-loadmore__tips').text('没有更多数据了');
                                //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                state=false;
                            }else{
                                // 否则继续
                                state=true;
                                $('.weui-loadmore .weui-loadmore__tips').text('点击加载更多');
                            }
                        },
                        error:function(XMLHttpRequest, textStatus, errorThrown){
                            $('.weui-loadmore .weui-loadmore__tips').text('加载错误,请刷新页面！');
                        }
                    });
                },500);
            }
        });
        // // //记录状态
        // var state=true;
        // //滚动条滚动的时候
        // $(window).scroll(function(){
        //     var loadmoreheight = $('.weui-loadmore').height();
        //     var tabbarheight = $('.weui-tabbar').height();
        //     console.log(tabbarheight);
        //     //获取当前加载更多按钮距离顶部的距离
        //     var bottomsubmit = $('.weui-loadmore').offset().top+tabbarheight+loadmoreheight;
        //     //获取当前页面底部距离顶部的高度距离
        //     var nowtop = $(document).scrollTop()+$(window).height();
        //     console.log($(document).scrollTop())
        //     console.log($(window).height())
        //     console.log(bottomsubmit)
        //     console.log(nowtop)
        //     //获取当前页数，默认第一页
        //     var now = $('.weui-loadmore').attr('now');
        //     //获取总页数，PHP分页的总页数
        //     var num = $('.weui-loadmore').attr('num');
        //     //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
        //     if(nowtop>bottomsubmit){
        //         //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
        //         if(state==true){
        //             //执行一次获取数据并停止再进来获取数据
        //             state=false;
        //             $('.weui-loadmore .weui-loading').show();
        //             $('.weui-loadmore .weui-loadmore__tips').text('正在加载');
        //             setTimeout(function(){
        //                 //当前页数++
        //                 now++;
        //                 //记录当前为第二页
        //                 $('.weui-loadmore').attr('now',now);
        //                 $.ajax({
        //                     //通过ajax传页数参数获取当前页数的数据
        //                     url:api+'?page='+now,
        //                     type:'POST',
        //                     cache:false,
        //                     data:{
        //                         module:'market',
        //                         method:'market',
        //                         request_mode:'get',
        //                         key:key,
        //                         sign:sign,
        //                         timestamp:timestamp
        //                     },
        //                     dataType:"json",
        //                     success:function(data){
        //                         console.log(data);
        //                         //把通过php处理的html和数据，写入容器底部
        //                         var indexlist = '';
        //                         for(var i=0;i<data.result.length;i++){
        //                             var index = data.result[i];
        //                             indexlist +='<li><a href="#"><div class="courses_img"><img src="images/img_03.png"></div><div class="courses_brief"><h5>痛风谈吃：细说痛风患者如何饮食</h5><div class="courses_brief_bottom"><span>销量:<b>6655</b></span><img src="images/line.png"/><span>点击量:<b>25525</b></span></div></div><div class="courses_right fr"><button><b>￥</b><span>19.99</span></button><div><span>会员免费</span></div></div></a></li>';
        //                         }
        //                         $('.courses_list_info').append(indexlist);
        //                         $('.weui-loadmore .weui-loading').hide();
        //                         //如果当前页大于等于总页数就提示没有更多数据
        //                         if(now>=num){
        //                             $('.weui-loadmore .weui-loadmore__tips').text('没有更多数据了');
        //                             //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
        //                             state=false;
        //                         }else{
        //                             // 否则继续
        //                             state=true;
        //                             $('.weui-loadmore .weui-loadmore__tips').text('上拉加载更多');
        //                         }
        //                     },
        //                     error:function(XMLHttpRequest, textStatus, errorThrown){
        //                         $('.weui-loadmore .weui-loadmore__tips').text('加载错误,请刷新页面！');
        //                     }
        //                 });
        //             },500);
        //         }
        //     }
        // });

    })
});