/**
 * Created by Administrator on 2018/11/13.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata'],function ($,wui,validata) {
        $(document).ready(function(){
            $('.courses_list_info li .courses_img img').height($('.courses_list_info li .courses_img').width()*1.33);
            var btn_height = $('.courses_list .courses_list_info li .courses_right button').height()/2;
            $('.courses_list .courses_list_info li .courses_right button').css('border-radius',btn_height + 'px')
        });
    })
});
