/**
 * Created by Administrator on 2018/11/13.
 */
define(['jquery','md5'],function ($) {
    return {
        getQueryString:function (name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return unescape(r[2]); return null;
        },
        isEqual:function (str1,str2) {
            return str1 === str2;
        },
        isApi:function () {
          return api = 'http://api.store.zhongmeiyixue.com/api/index';
        },
        formatTime:function (seconds) {
            return [
                parseInt(seconds / 60 % 60),
                parseInt(seconds % 60)
            ]
            .join(":")
            .replace(/\b(\d)\b/g, "0$1");
        },
        signCont:function() {
            var timestamp = Date.parse(new Date()) / 1000;
            var sign = 'wx_first' + timestamp + 'ezYQAe5UEi5UMHtY';
            sign = $.md5(sign);
            var signCont = {
                key: 'wx_first',
                sign: sign,
                timestamp: timestamp
            };
            return signCont
        }
    }
});