/**
 * Created by Administrator on 2018/11/21.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);

    })
});