/**
 * Created by Administrator on 2018/11/15.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        //横向滑动导航
        var oBox = $('.box');
        var oBoxWidth = $('.box').width();
        $(document).find(oBox).find('div').on('click',function(){
            var thisWidth = $(this).width();
            var moveLeft = this.offsetLeft;
            if(oBoxWidth/2<moveLeft+thisWidth/2){
                oBox.animate({scrollLeft:moveLeft+thisWidth/2-oBoxWidth/2});
            }else{
                oBox.animate({scrollLeft:0});
            }
            $(this).parents('.box').find('div').find('p').removeClass('active')
            $(this).find('p').addClass('active');
        });


    })
});